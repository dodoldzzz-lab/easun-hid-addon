#!/bin/bash
python3 /app/easun_hid.py
